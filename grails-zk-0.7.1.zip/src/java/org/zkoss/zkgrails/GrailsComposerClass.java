package org.zkoss.zkgrails;

public interface GrailsComposerClass {

}